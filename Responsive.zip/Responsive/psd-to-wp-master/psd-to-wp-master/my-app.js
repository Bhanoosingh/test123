$(document).ready(function(){
	$("#btn").click(function(){
		$("#nav").toggleClass("hide");
	});
});