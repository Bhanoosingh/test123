package Date_23_03_2019;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.TreeSet;

public class Diff {

	public static void main(String[] args) {
		List<Integer> listCollect=new ArrayList<>();
		Queue<Integer> queueCollect=new PriorityQueue<>();
		
		
		listCollect.add(1);
		listCollect.add(11);
		listCollect.add(12);
		listCollect.add(11);
		
		listCollect.remove(1);
		System.out.println("List=>"+listCollect);
		
		
		queueCollect.add(166);
		queueCollect.add(11);
		queueCollect.add(12);
		queueCollect.add(11);
		
		queueCollect.remove();
		System.out.println("Queue=>"+queueCollect);
		

		
	}

}
