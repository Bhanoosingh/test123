package Date_23_03_2019;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

public class Exp2 {

	public static void main(String[] args)throws IOException {
		BufferedReader br=
				new BufferedReader(
						new InputStreamReader(System.in));
		Set<Integer> listExp=new HashSet<>();
		String ch="n";
		do {
			System.out.println("Enter a number:-");
			listExp.add(Integer.parseInt(br.readLine()));
			
			System.out.println("Do you want to continue ?Y/N");
			ch=br.readLine();
		}while(ch.equalsIgnoreCase("y"));
		
		
		
		System.out.println(listExp.size());
		
		listExp.remove(1);

	}

}
