package Date_23_03_2019;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Exp3 {

	public static void main(String[] args) {
		List<User> listUser=Arrays.asList(
				new User(1,"Bhanoo","123456"),
				new User(2,"Atul","123456"),
				new User(3,"Akram","123456"),
				new User(4,"Abhinav","123456"),
				new User(5,"Abhishek","123456"),
				new User(6,"Arush","123456")); 
		
		listUser.forEach(u->System.out.println(u));
		
		
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Select a user id:-");
		int n=sc.nextInt();
		System.out.println(listUser.stream().filter(u->u.getId()==n).findFirst().get());

	}

}
